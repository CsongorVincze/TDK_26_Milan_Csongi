#!/usr/bin/env python3
"""Convergence estimates with outward-rounded bracket propagation and GCI."""
import csv,json,math,itertools
from pathlib import Path
import numpy as np
import run as r

# Intervals below propagate the saved amplitude brackets through the Richardson
# model. They do NOT enclose a continuum PDE solution or prove the error model.
def down(x):return math.nextafter(x,-math.inf)
def up(x):return math.nextafter(x,math.inf)
def add(a,b):return (down(a[0]+b[0]),up(a[1]+b[1]))
def neg(a):return (-a[1],-a[0])
def sub(a,b):return add(a,neg(b))
def mul(a,b):
    v=[x*y for x in a for y in b];return (down(min(v)),up(max(v)))
def div(a,b):
    if b[0]<=0<=b[1]:raise ValueError('Interval denominator includes zero')
    return mul(a,(down(1/b[1]),up(1/b[0])))
def square(a):
    v=[a[0]*a[0],a[1]*a[1]]
    return (0 if a[0]<=0<=a[1] else down(min(v)),up(max(v)))
def bracket(row):return (row['lower'],row['upper'])
def extrapolate(rows):
    a,b,c=rows
    d0=a['midpoint']-b['midpoint'];d1=b['midpoint']-c['midpoint']
    ratio=d0/d1
    if ratio<=1:raise ValueError('Not a monotone converging triplet')
    p=math.log2(ratio)
    limit=c['midpoint']-d1*d1/(d0-d1)
    D0=sub(bracket(a),bracket(b));D1=sub(bracket(b),bracket(c))
    R=div(D0,D1)
    if R[0]<=1:raise ValueError('Brackets do not establish convergence')
    P=(down(math.log2(R[0])),up(math.log2(R[1])))
    E=sub(bracket(c),div(square(D1),sub(D0,D1)))
    return dict(coarse_n=a['n'],middle_n=b['n'],fine_n=c['n'],p=p,p_interval=P,
                extrapolated=limit,extrapolation_interval=E,
                propagated_search_halfwidth=max(limit-E[0],E[1]-limit),
                fine_grid_correction=abs(limit-c['midpoint']),
                gci_absolute=1.25*abs(limit-c['midpoint']))

def load(name):return json.loads((r.OUT/f'{name}.json').read_text())
def main():
    second=[load(name) for name in ['order2_first_N500','order2_N999','order2_N1997','order2_N3993']]
    fourth=[load(f'order4_N{n}') for n in [500,999,1997,3993] if (r.OUT/f'order4_N{n}.json').exists()]
    assert len(fourth)>=3
    schemes={}
    for label,rows in [('second',second),('fourth',fourth)]:
        est=[extrapolate(rows[i:i+3]) for i in range(len(rows)-2)]
        schemes[label]=dict(grids=rows,triplets=est)
    checks=json.loads((r.OUT/'sensitivity_summary.json').read_text())
    base=load('order4_N999')
    sensitivities=[]
    for check in checks:
        shift=abs(check['midpoint']-base['midpoint'])
        envelope=shift+check['half_width']+base['half_width']
        sensitivities.append(dict(name=check['name'],shift=shift,bracket_inclusive_shift=envelope))
    e4=schemes['fourth']['triplets'][-1];e2=schemes['second']['triplets'][-1]
    center=e4['extrapolated']
    independent_difference=abs(e2['extrapolated']-center)
    # Conservative empirical/model-based budget, not a statistical confidence interval.
    spatial=max(e4['gci_absolute'],independent_difference+e2['propagated_search_halfwidth']+e4['propagated_search_halfwidth'])
    stability=0
    if len(schemes['fourth']['triplets'])>1:
        prior=schemes['fourth']['triplets'][-2]
        stability=abs(prior['extrapolated']-center)+prior['propagated_search_halfwidth']+e4['propagated_search_halfwidth']
        spatial=max(spatial,stability)
    # Do not shrink N=999 sensitivity estimates when reporting the finer-grid limit.
    # Sum rather than quadrature because these are deterministic systematic checks.
    def envelope(names):return max(x['bracket_inclusive_shift'] for x in sensitivities if x['name'] in names)
    temporal=envelope(['check_cfl02','check_cfl01'])
    domain=envelope(['check_domain50','check_domain75','check_sponge35','check_no_sponge','check_combined'])
    criterion=envelope(['check_horizon200','check_cutoff48','check_cutoff96','check_combined'])
    arithmetic=envelope(['check_extended'])
    search=e4['propagated_search_halfwidth']
    total=spatial+temporal+domain+criterion+arithmetic+search
    # Round uncertainty upward to one significant decimal digit, include center rounding.
    exponent=10**math.floor(math.log10(total));reported_u=math.ceil(total/exponent)*exponent
    decimals=max(0,-math.floor(math.log10(reported_u)))
    rounded_center=round(center,decimals)
    reported_u=math.ceil((total+abs(center-rounded_center))/exponent)*exponent
    budget=dict(spatial_model_and_independent_method=spatial,time_step=temporal,
                domain_and_sponge=domain,horizon_and_cutoff=criterion,arithmetic=arithmetic,
                propagated_bisection=search,total_unrounded=total,reported_uncertainty=reported_u)
    result=dict(critical_amplitude=center,reported_center=rounded_center,reported_uncertainty=reported_u,
                uncertainty_type='Conservative model-based numerical estimate; not a rigorous PDE bound or a statistical confidence interval',
                branch='First positive-field collapse onset in the mapped neighborhood near A=1.20261',
                schemes=schemes,sensitivities=sensitivities,error_budget=budget,
                independent_extrapolation_difference=independent_difference,
                fourth_extrapolation_stability=stability,
                delta_min_for_one_percent_distance_uncertainty=reported_u/(.01*rounded_center-1.01*reported_u))
    (r.OUT/'determination.json').write_text(json.dumps(result,indent=2)+'\n')
    r.csvwrite('error_budget.csv',[dict(component=k,absolute_amplitude_error=v) for k,v in budget.items()])
    r.csvwrite('sensitivity_differences.csv',sensitivities)
    # Export uniform grid rows with both numerical midpoints and search brackets.
    r.csvwrite('grid_convergence.csv',[dict(scheme=label,n=row['n'],h=1/(row['n']-1),
                    lower=row['lower'],upper=row['upper'],midpoint=row['midpoint'],half_width=row['half_width'])
                    for label,data in schemes.items() for row in data['grids']])
    offset_rows=[]
    for delta in [1e-4,1e-6,1e-8,1e-10]:
        amplitude=rounded_center*(1+delta)
        low=down(amplitude/(rounded_center+reported_u)-1)
        high=up(amplitude/(rounded_center-reported_u)-1)
        actual=(amplitude-rounded_center)/rounded_center
        offset_rows.append(dict(requested_delta=delta,amplitude=amplitude,actual_nominal_delta=actual,
                                delta_lower=low,delta_upper=high,max_fractional_distance_uncertainty=max(actual-low,high-actual)/actual))
    r.csvwrite('usable_offsets.csv',offset_rows)
    figures(result)
    print(json.dumps({k:result[k] for k in ['critical_amplitude','reported_center','reported_uncertainty','error_budget','delta_min_for_one_percent_distance_uncertainty']},indent=2))

def figures(result):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.style.use(r.HERE.parent/'tdk.mplstyle')
    center=result['critical_amplitude']
    fig,axes=plt.subplots(1,2,figsize=(12,4.8),layout='constrained')
    for label,color,marker,title in [('second','#1f77b4','o','Second-order spatial stencil'),('fourth','#e2642a','s','Fourth-order spatial stencil')]:
        data=result['schemes'][label];rows=data['grids'];h=np.array([1/(x['n']-1) for x in rows]);a=np.array([x['midpoint'] for x in rows])
        axes[0].loglog(h,abs(a-center),marker+'-',color=color,label=title)
        power=2 if label=='second' else 4
        axes[0].loglog(h,abs(a[0]-center)*(h/h[0])**power,':',color=color,alpha=.6,label=f'$h^{power}$ reference')
        estimates=data['triplets']
        for i,e in enumerate(estimates):
            axes[1].errorbar(e['fine_n'],(e['extrapolated']-center)/1e-12,
                            yerr=e['propagated_search_halfwidth']/1e-12,fmt=marker,color=color,
                            label=title if i==0 else None,capsize=3)
    axes[0].set(xlabel='Computational grid spacing, h',ylabel=r'$|A_c(h)-\widehat{A}_c|$',title='(a) Independent spatial convergence')
    axes[0].legend(fontsize=8)
    axes[1].axhspan(-result['reported_uncertainty']/1e-12,result['reported_uncertainty']/1e-12,color='#dce7f5',alpha=.6,label='Reported numerical uncertainty')
    axes[1].axhline(0,color='#243449',lw=.7)
    axes[1].set(xlabel='Finest grid size in Richardson triplet, N',ylabel=r'Extrapolated shift from reference ($10^{-12}$)',title='(b) Continuum extrapolations')
    axes[1].legend(fontsize=8)
    fig.suptitle('Gaussian critical amplitude: branch-aligned convergence',fontsize=12,fontweight='bold')
    fig.savefig(r.OUT/'critical_convergence.png',dpi=300);plt.close(fig)
    path=r.OUT/'branch_map_initial.csv'
    if path.exists():
        with path.open() as f:rows=list(csv.DictReader(f))
        fig,axes=plt.subplots(3,1,figsize=(10,6),layout='constrained',sharex=True)
        for ax,(n,variant) in zip(axes,[(500,'order2'),(999,'order2'),(500,'order4')]):
            group=[x for x in rows if int(x['n'])==n and x['variant']==variant]
            for sign,color,marker,text in [(0,'#8064a2','x','No crossing by t=100'),(1,'#1f77b4','o','Positive-field collapse'),(-1,'#e2642a','v','Negative-field collapse')]:
                selected=[x for x in group if int(x['event_sign'])==sign]
                ax.scatter([(float(x['amplitude'])-center)/center for x in selected],
                           [float(x['end_time']) for x in selected],marker=marker,color=color,s=20,label=text)
            ax.set(title=f'{variant.replace("order", "Order ")} | N = {n}',ylabel='Cutoff time / horizon')
            ax.set_ylim(0,110)
        axes[0].legend(fontsize=7,ncols=3,loc='center')
        axes[-1].set_xlabel(r'Raw offset from continuum estimate, $(A-\widehat{A}_c)/\widehat{A}_c$')
        axes[-1].ticklabel_format(axis='x',style='sci',scilimits=(0,0))
        fig.suptitle('Why the collapse branch must be tracked',fontsize=12,fontweight='bold')
        fig.savefig(r.OUT/'branch_tracking.png',dpi=300);plt.close(fig)
if __name__=='__main__':main()
