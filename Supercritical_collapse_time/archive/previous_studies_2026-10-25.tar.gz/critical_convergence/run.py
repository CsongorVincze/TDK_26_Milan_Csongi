#!/usr/bin/env python3
"""Cached branch-tracked critical-amplitude convergence experiments."""
import argparse,csv,hashlib,json,math,os,subprocess,threading,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/tdk-critical-mpl')
import numpy as np
HERE=Path(__file__).resolve().parent
OUT=HERE/'results';OUT.mkdir(exist_ok=True)
SOURCE=hashlib.sha256((HERE/'solver.cpp').read_bytes()).hexdigest()
LOCK=threading.Lock();CACHE={}
JOURNAL=OUT/'trials.jsonl'
if JOURNAL.exists():
    for line in JOURNAL.read_text().splitlines():
        try:r=json.loads(line);CACHE[r['key']]=r
        except (ValueError,KeyError):pass

def csvwrite(name,rows):
    with (OUT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def build():
    for variant,flags in [('order2',[]),('order4',['-DSPATIAL_ORDER=4']),('extended',['-DEXTENDED_PRECISION']),('order4_extended',['-DSPATIAL_ORDER=4','-DEXTENDED_PRECISION'])]:
        subprocess.run(['g++','-O3','-std=c++17',*flags,str(HERE/'solver.cpp'),'-o',str(HERE/f'solver_{variant}')],check=True)

def sim(a,n=500,cfl=.4,horizon=100,level=12,radius=25,start=20,strength=7,variant='order2',trajectory=None):
    settings=dict(amplitude=float(a),n=int(n),cfl=float(cfl),horizon=float(horizon),level=float(level),radius=float(radius),sponge_start=float(start),sponge_strength=float(strength),variant=variant)
    key=json.dumps(dict(source=SOURCE,**settings),sort_keys=True)
    if trajectory is None and key in CACHE:return CACHE[key]
    t0=time.monotonic()
    p=subprocess.run([str(HERE/f'solver_{variant}'),repr(float(a)),str(n),str(cfl),str(horizon),str(level),str(radius),str(start),str(strength),'.02',str(OUT/trajectory) if trajectory else '-'],check=True,capture_output=True,text=True)
    event,end,steps,sign,peak,final,actual,t12,t24=p.stdout.split()
    row=dict(key=key,**settings,collapsed=int(event),end_time=float(end),steps=int(steps),event_sign=int(sign),peak_center=float(peak),final_center=float(final),actual_radius=float(actual),t12=float(t12),t24=float(t24),wall_seconds=time.monotonic()-t0)
    with LOCK:
        CACHE[key]=row
        with JOURNAL.open('a') as f:f.write(json.dumps(row)+'\n')
    return row

def threshold(name,seed,halfwidth,n=500,tolerance=2e-12,**kwargs):
    path=OUT/f'{name}.json'
    if path.exists():
        prior=json.loads(path.read_text())
        if prior.get('source')==SOURCE and prior['width']<=tolerance:return prior
        if prior.get('source')==SOURCE:
            seed=prior['midpoint'];halfwidth=prior['width']/2
    trials=[]
    def classify(a):
        row=sim(a,n=n,**kwargs);trials.append({k:v for k,v in row.items() if k!='key'})
        print(f'{name} A={a:.15f} event={row["collapsed"]} t={row["end_time"]:.4f}',flush=True)
        return row['collapsed']
    lo,hi=seed-halfwidth,seed+halfwidth
    for attempt in range(10):
        low,high=classify(lo),classify(hi)
        if not low and high:break
        halfwidth*=2;lo,hi=seed-halfwidth,seed+halfwidth
    else:raise RuntimeError(f'{name}: could not straddle selected branch')
    while hi-lo>tolerance:
        mid=(lo+hi)/2
        if mid in [lo,hi]:break
        if classify(mid):hi=mid
        else:lo=mid
    ordered=sorted(trials,key=lambda r:r['amplitude'])
    # Every observed outcome within this local bracket must agree with one transition.
    seen_collapse=False
    for row in ordered:
        if row['collapsed']:seen_collapse=True
        elif seen_collapse:raise RuntimeError(f'{name}: non-monotone local outcomes')
    result=dict(name=name,source=SOURCE,n=n,**kwargs,lower=lo,upper=hi,midpoint=(lo+hi)/2,width=hi-lo,half_width=(hi-lo)/2,trials=len(trials))
    csvwrite(f'{name}_trials.csv',trials)
    path.write_text(json.dumps(result,indent=2)+'\n')
    print('RESULT',json.dumps(result),flush=True)
    return result

def grid_sequence(variant,ns):
    results=[]
    for n in ns:
        if variant=='order2':
            if not results:seed,half=1.20260535,3e-7
            elif len(results)==1:seed,half=1.20260865,1e-7
            else:
                difference=results[-1]['midpoint']-results[-2]['midpoint']
                seed=results[-1]['midpoint']+difference/4
                half=max(abs(difference)*.15,1e-10)
        else:
            seed=results[-1]['midpoint'] if results else 1.2026097332
            half=2e-9
        name=f'{variant}_first_N{n}' if variant=='order2' and n==500 else f'{variant}_N{n}'
        results.append(threshold(name,seed,half,n=n,variant=variant,tolerance=5e-14 if variant=='order4' else 2e-12))
    csvwrite(f'{variant}_summary.csv',results)
    return results

def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['build','second','fourth','checks','first500','fourthfine','maps','branches','fixed','all']);args=ap.parse_args()
    if args.stage=='build':build()
    elif args.stage=='second':grid_sequence('order2',[500,999,1997,3993])
    elif args.stage=='fourth':grid_sequence('order4',[500,999,1997])
    elif args.stage=='first500':threshold('order2_first_N500',1.20260535,3e-7,n=500,variant='order2')
    elif args.stage=='fourthfine':
        base=json.loads((OUT/'order4_N1997.json').read_text())
        threshold('order4_N3993',base['midpoint'],1e-10,n=3993,variant='order4',tolerance=5e-14)
    elif args.stage=='all':
        import sys
        build()
        for stage in ['maps','second','fourth','fourthfine','checks','branches']:
            subprocess.run([sys.executable,str(HERE/'run.py'),stage],check=True)
        for script in ['validate.py','analyze.py']:
            subprocess.run([sys.executable,str(HERE/script)],check=True)
        subprocess.run([sys.executable,str(HERE/'run.py'),'fixed'],check=True)
        subprocess.run([sys.executable,str(HERE/'write_report.py')],check=True)
    elif args.stage=='maps':
        jobs=[(n,a,v) for n,v in [(500,'order2'),(999,'order2'),(500,'order4')] for a in np.linspace(1.202602,1.202614,25)]
        def work(job):
            n,a,v=job;row=sim(a,n=n,variant=v)
            return {k:v for k,v in row.items() if k!='key'}
        with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(work,jobs))
        csvwrite('branch_map_initial.csv',rows)
    elif args.stage=='branches':
        names=['order2_first_N500']+[f'order2_N{n}' for n in [999,1997,3993]]+[f'order4_N{n}' for n in [500,999,1997,3993]]
        def work(name):
            base=json.loads((OUT/f'{name}.json').read_text())
            endpoint=sim(base['upper'],n=base['n'],variant=base['variant'])
            assert endpoint['collapsed'] and endpoint['event_sign']==1,(name,endpoint)
            row=sim(base['midpoint']*(1+1e-7),n=base['n'],variant=base['variant'],level=48,trajectory=f'branch_{name}.csv')
            assert row['event_sign']==1,(name,row)
            return dict(case=name,reference_amplitude=base['midpoint'],raw_offset=1e-7,**{k:v for k,v in row.items() if k!='key'})
        with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(work,names))
        csvwrite('branch_validation.csv',rows)
    elif args.stage=='fixed':
        result=json.loads((OUT/'determination.json').read_text());ac=result['critical_amplitude'];amplitude=ac*(1+1e-8)
        def work(item):
            n,cfl=item;row=sim(amplitude,n=n,cfl=cfl,variant='order4',level=96,trajectory=f'fixed_delta1e-8_N{n}_cfl{cfl}.csv')
            assert row['event_sign']==1
            return dict(reference=ac,requested_raw_offset=1e-8,**{k:v for k,v in row.items() if k!='key'})
        with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(work,[(999,.4),(1997,.4),(3993,.4),(1997,.2)]))
        csvwrite('fixed_amplitude_validation.csv',rows)
    elif args.stage=='checks':
        base=json.loads((OUT/'order4_N999.json').read_text());seed=base['midpoint']
        settings=[('cfl02',dict(cfl=.2)),('cfl01',dict(cfl=.1)),
                  ('horizon200',dict(horizon=200)),('cutoff48',dict(level=48)),
                  ('domain50',dict(radius=50,start=40)),('domain75',dict(radius=75,start=60)),
                  ('combined',dict(radius=75,start=60,horizon=200,level=96,cfl=.2)),('sponge35',dict(strength=3.5)),('cutoff96',dict(level=96)),('no_sponge',dict(strength=0)),('extended',dict(variant='order4_extended'))]
        def work(item):
            name,changes=item;options=dict(variant='order4');options.update(changes)
            return threshold('check_'+name,seed,2e-11,n=999,tolerance=5e-14,**options)
        with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(work,settings))
        # Uniform output fields avoid a heterogeneous CSV schema for settings.
        (OUT/'sensitivity_summary.json').write_text(json.dumps(rows,indent=2)+'\n')
if __name__=='__main__':main()
