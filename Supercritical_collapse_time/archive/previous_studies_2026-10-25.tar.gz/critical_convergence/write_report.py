#!/usr/bin/env python3
"""Explain the measured determination and its conditional numerical uncertainty."""
import csv,json,math,platform,subprocess
from pathlib import Path
import run as r

def main():
    d=json.loads((r.OUT/'determination.json').read_text())
    center=d['reported_center'];u=d['reported_uncertainty'];budget=d['error_budget']
    s2=d['schemes']['second'];s4=d['schemes']['fourth']
    def gridtable(label,data):
        text=f'\n{label}:\n\n| N | Critical midpoint | Search half-width |\n| ---: | ---: | ---: |\n'
        for x in data['grids']:text+=f'| {x["n"]} | {x["midpoint"]:.15f} | {x["half_width"]:.3e} |\n'
        return text
    table=gridtable('Second-order spatial discretization',s2)+gridtable('Fourth-order spatial discretization',s4)
    with (r.OUT/'usable_offsets.csv').open() as f:offsets=list(csv.DictReader(f))
    offsettable='| Target raw delta | Starting amplitude | Estimated interval for delta | Relative uncertainty in distance |\n| ---: | ---: | ---: | ---: |\n'
    for row in offsets:
        nominal=float(row['requested_delta']);a=float(row['amplitude']);lo=float(row['delta_lower']);hi=float(row['delta_upper']);rel=float(row['max_fractional_distance_uncertainty'])
        offsettable+=f'| {nominal:.0e} | {a:.15f} | [{lo:.7e}, {hi:.7e}] | {rel:.3e} |\n'
    btable='| Contribution | Absolute amplitude allowance |\n| --- | ---: |\n'
    labels={'spatial_model_and_independent_method':'Spatial convergence and independent-method comparison',
            'time_step':'Time-step sensitivity','domain_and_sponge':'Outer domain and sponge',
            'horizon_and_cutoff':'Horizon and collapse cutoff','arithmetic':'Arithmetic precision',
            'propagated_bisection':'Propagated search brackets'}
    for key,label in labels.items():btable+=f'| {label} | {budget[key]:.3e} |\n'
    btable+=f'| Sum before reporting/rounding | {budget["total_unrounded"]:.3e} |\n| Reported allowance | {u:.1e} |\n'
    fixed=''
    fp=r.OUT/'fixed_amplitude_validation.csv'
    if fp.exists():
        with fp.open() as f:rows=list(csv.DictReader(f))
        fixed='\n## Check of one specified supercritical amplitude\n\n'
        fixed+=f'The same amplitude A={float(rows[0]["amplitude"]):.16f}, nominal raw delta=1e-8 relative to the unrounded continuum estimate, was run with the fourth-order stencil:\n\n'
        fixed+='| N | CFL | Time to 12 | Time to 24 | Time to 96 |\n| ---: | ---: | ---: | ---: | ---: |\n'
        for row in rows:fixed+=f'| {row["n"]} | {row["cfl"]} | {float(row["t12"]):.10f} | {float(row["t24"]):.10f} | {float(row["end_time"]):.10f} |\n'
        fixed+='\nAll four runs reach positive field 96. These are cutoff times, **not** extrapolated singularity times. This test checks the same initial condition across grids; it does not retune the amplitude to each grid threshold. A blow-up-time estimate still needs a resolved late-field fit and its own convergence study.\n'
    text=f'''# Critical Gaussian amplitude: convergence and numerical error

## Result

For the positive-field collapse onset near A=1.20261 in the 3D Gaussian family,

**Ac = {center:.12f} ± {u:.1e}**, dimensionless.

This is a conservative **model-based numerical uncertainty estimate**. It is
not a rigorous enclosure of the infinite-domain PDE threshold and not a
statistical confidence interval. The estimated band is
[{center-u:.15f}, {center+u:.15f}]. It includes measured discretization and
sensitivity allowances, under the convergence assumptions described below.

The initial data are phi(r,0)=A exp(-r²/8), pi(r,0)=0 (R0=2). The PDE is
phi_tt=phi_rr+(2/r)phi_r-phi+phi³, with the original outer sponge tested
separately. The operational classification starts with reaching |phi(0,t)|=12
by t=100. Its stability is tested to t=200 and cutoff 96.

## An important correction to the earlier reference

The old N=500 reference, 1.2026097002647, was a **later negative-field
collapse-window edge**. It was not the first onset in its neighborhood.
The new amplitude map finds positive-field collapse already near
A=1.2026055 on that grid, followed by a non-crossing interval and then the
old negative-field branch. Thus the previous N=500/N=1000 comparison mixed
different boundaries and could not be used as a spatial error estimate.

Here, the positive-field onset is selected and tracked consistently. Its
N=500 second-order value is {s2['grids'][0]['midpoint']:.15f}. Every selected
collapsing bracket endpoint is verified to reach positive field 12, and
branch-validation runs at raw offset 1e-7 reach positive field 48. The scan
establishes the onset within the mapped neighborhood [1.202602,1.202614]; it
does not prove that no other collapse islands exist at arbitrary lower A.
As there are multiple windows, Ac must always identify the chosen boundary.

## How the determination was calculated

The stretched radial map and inner nodes are fixed. Nested grids use
N=500,999,1997,3993, giving an exact factor of two in computational spacing
h=1/(N-1). The time step scales with h at CFL=0.4. Two spatial methods are
compared: the original second-order stencil and a fourth-order stencil
including an even-origin stencil. RK4, potential, Gaussian profile, and
boundary convention are otherwise shared.

The new stencils were first tested against the analytic radial Laplacian
of a Gaussian. Their observed interior convergence orders are approximately
2.0001 and 3.9993. The accelerated original stencil also reproduces the
original Python solver's event times within floating-point roundoff on two
independent comparison runs. The fourth-order stencil falls back to second
order next to the outer boundary; actual threshold convergence and the
extended-domain tests verify that this does not dominate this calculation.

Each threshold has opposite classified bracket endpoints. Bisection search
half-widths are kept separate from spatial error:
{table}

## Richardson extrapolation and spatial uncertainty

For one tracked boundary, the tested leading-error model is

    Ac(h) = Ac(0) + C h^p + higher-order terms.

For three grids h,h/2,h/4, let d0=Ac(h)-Ac(h/2) and
d1=Ac(h/2)-Ac(h/4). Then

    p = log2(d0/d1)
    Ac(0)_estimate = Ac(h/4) - d1²/(d0-d1).

Observed orders from successive triplets:

- Second-order scheme: {', '.join(f'{e["p"]:.6f}' for e in s2['triplets'])}.
- Fourth-order scheme: {', '.join(f'{e["p"]:.6f}' for e in s4['triplets'])}.

The latest second-order extrapolation is {s2['triplets'][-1]['extrapolated']:.15f}.
The latest fourth-order extrapolation is {s4['triplets'][-1]['extrapolated']:.15f}.
Their difference is {d['independent_extrapolation_difference']:.3e}.
The fourth-order estimate is the central reported value before rounding.

The standard absolute Grid Convergence Index allowance on the fine grid is

    U_GCI = 1.25 |Ac(0)_estimate - Ac(h_fine)|.

The safety factor 1.25 and observed-order approach follow the
[NASA/NPARC convergence guidance](https://www.grc.nasa.gov/www/wind/valid/tutorial/spatconv.html).
This allowance is an engineering numerical estimate, not a theorem proving
that the exact PDE threshold lies inside it.

For the reported spatial allowance, take the maximum of the fourth-order
GCI, the discrepancy between independent-scheme extrapolations (including
their propagated search brackets), and the change between successive
fourth-order extrapolations (also including search brackets). This prevents
reporting a small GCI when the independent checks disagree.

Bracket propagation uses outward-rounded interval arithmetic through the
Richardson expression. It bounds the effect of the supplied search intervals
**within that algebraic extrapolation model**. It does not bound omitted
higher-order terms or convert a floating-point solver into a validated PDE
solver. Those are assessed empirically by the extra grid and independent
stencil.

## Other error sources and the combined estimate

At the N=999 fourth-order grid, independent local searches tested CFL=0.2
and 0.1; horizon 200; cutoffs 48 and 96; extended outer radii at least 50
and 75; sponge strength 3.5 and zero; and extended floating-point precision
(long double). A joint test also combines radius at least 75, horizon 200,
cutoff 96, and CFL=0.2. Domain extension adds outer grid nodes, preserving every
inner grid point and the inner time-step scale. The sponge is moved outward
for larger domains, not simply rescaled on an altered core grid.

No systematic shift is resolved beyond the search intervals in these tests.
For each setting, its allowance is the absolute midpoint shift plus both
search half-widths. For each category, use the largest allowance among its
tests and retain that N=999 value without reducing it for finer grids.
The deterministic contributions are added, not combined as independent
random standard deviations:

{btable}

The allowance is rounded upward for presentation, including rounding of the
reported center. Extended arithmetic agrees at the tested grid, but this
is not a formal roundoff bound. The budget also assumes the observed spatial
convergence persists and that the tested domain/horizon/cutoff variations
are representative. A rigorous mathematical guarantee would require a
validated PDE error analysis or interval-in-time/space solver; that has not
been performed here.

## How close can a supercritical run be labeled reliably?

For a fixed known starting amplitude A and an estimated threshold band
[Ac-U,Ac+U], the corresponding distance band is

    delta_min = A/(Ac+U)-1
    delta_max = A/(Ac-U)-1.

Thus an accurate Ac must be much more accurate than the imposed amplitude
excess. The following intervals use the reported threshold band and include
floating-point amplitude construction in the nominal delta. The final column
is a **fraction**, not a percentage:

{offsettable}

To limit uncertainty to 0.01 of the stated distance, the minimum raw offset
implied by this threshold allowance is approximately
{d['delta_min_for_one_percent_distance_uncertainty']:.3e}. This concerns the
threshold reference only; it is not a guarantee that the evolution or its
blow-up time is resolved at that distance.

In particular, do not use the new continuum Ac with the old N=500
second-order solver and assume delta=1e-8 is realized accurately. That grid's
same-branch threshold differs from the continuum estimate by about 4.34e-6.
Even N=3993 with the second-order stencil has a threshold shift about
6.78e-8. The fourth-order solver's grid thresholds are far closer to the
continuum estimate. A future near-critical collapse study should use the
fourth-order solver, compare fixed-A trajectories on multiple grids, and
separately verify the late collapsing core and blow-up-time estimator.
{fixed}
## Reproduction and artifacts

From the project root:

```bash
MPLCONFIGDIR=/tmp/tdk-critical-mpl python3 Supercritical_collapse_time/critical_convergence/run.py all
```

Requires Python, NumPy, Matplotlib, and g++. Simulations are cached by source
hash and all numerical settings in trials.jsonl. Delete or move the results
folder only if a fresh uncached rerun is desired; ordinary reruns reuse the
saved computations. No commit or push is performed. All figures are English
PNG exports following TDK_plot_skill; no PDFs are generated.

Key outputs:

- determination.json: full result, observed orders, and uncertainty components.
- grid_convergence.csv, error_budget.csv, sensitivity_differences.csv.
- *_trials.csv and trials.jsonl: every actual classification.
- critical_convergence.png: independent convergence and extrapolation checks.
- branch_tracking.png: the collapse windows and the old branch mismatch.
- branch_validation.csv and branch_*.csv: same-branch trajectory checks.
- fixed_amplitude_validation.csv and fixed_delta1e-8_*.csv.
- usable_offsets.csv: raw-offset uncertainty propagation.
- manufactured_stencil_validation.csv and evolution_validation.csv.

The main uncertainty calculation and all empirical assumptions are exposed
in analyze.py; it does not attach an unsupported statistical confidence level.
'''
    (r.OUT/'REPORT.md').write_text(text)
    versions=dict(python=platform.python_version(),numpy=np.__version__,compiler=subprocess.run(['g++','--version'],capture_output=True,text=True,check=True).stdout.splitlines()[0],solver_source_sha256=r.SOURCE)
    (r.OUT/'environment.json').write_text(json.dumps(versions,indent=2)+'\n')
    print('Wrote',r.OUT/'REPORT.md')
if __name__=='__main__':
    import numpy as np
    main()
