#!/usr/bin/env python3
"""Validate origin/interior stencils and accelerated reference evolution."""
import csv,importlib.util,sys
import numpy as np
import run as r

def laplacian(n,order):
    x=np.linspace(0,1,n);dx=x[1];rad=25*np.sinh(5*x)/np.sinh(5)
    rx=125*np.cosh(5*x)/np.sinh(5);rxx=25*rad
    f=np.exp(-rad*rad/8)
    exact=(rad*rad/16-.75)*f
    lap=np.zeros(n)
    for i in range(1,n-2):
        if order==2:
            pxx=(f[i+1]-2*f[i]+f[i-1])/dx**2;px=(f[i+1]-f[i-1])/(2*dx)
        else:
            fm2=f[1] if i==1 else f[i-2]
            pxx=(-f[i+2]+16*f[i+1]-30*f[i]+16*f[i-1]-fm2)/(12*dx**2)
            px=(-f[i+2]+8*f[i+1]-8*f[i-1]+fm2)/(12*dx)
        lap[i]=pxx/rx[i]**2+(2/(rad[i]*rx[i])-rxx[i]/rx[i]**3)*px
    lap[0]=(6*(f[1]-f[0]) if order==2 else (-f[2]+16*f[1]-15*f[0])/2)/(rx[0]*dx)**2
    # Very near origin cancellation limits fourth-order measurements at fine h.
    use=(rad<=8)&(rad>=.2)
    return np.max(np.abs(lap[use]-exact[use])),abs(lap[0]-exact[0])

def main():
    rows=[]
    for order in [2,4]:
        errors=[]
        for n in [125,249,497]:
            interior,origin=laplacian(n,order);errors.append(interior)
            rows.append(dict(order=order,n=n,interior_max_error=interior,origin_error=origin))
        p=np.log2(errors[-2]/errors[-1]);assert p>order-.25,(order,p)
        print('Manufactured Gaussian Laplacian order',order,'observed',p)
    r.csvwrite('manufactured_stencil_validation.csv',rows)
    path=r.HERE.parent.parent/'module4/milan_alapkod_module4.py'
    spec=importlib.util.spec_from_file_location('reference',path);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
    results=[]
    for amplitude in [1.203812310596742,1.3]:
        c=m.Config();g=m.make_grid(c);event,t,steps,_=m.simulate(amplitude,c,g,100,save=False)
        accelerated=r.sim(amplitude)
        assert event==bool(accelerated['collapsed']) and abs(t-accelerated['end_time'])<1e-7
        results.append(dict(amplitude=amplitude,reference_time=t,new_time=accelerated['end_time'],difference=abs(t-accelerated['end_time'])))
    r.csvwrite('evolution_validation.csv',results)
    print('Independent Python evolution comparisons passed.')
if __name__=='__main__':main()
